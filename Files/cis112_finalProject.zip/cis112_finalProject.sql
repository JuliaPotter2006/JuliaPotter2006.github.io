--
-- PostgreSQL database dump
--

-- Dumped from database version 14.5
-- Dumped by pg_dump version 16.3

-- Started on 2025-04-23 12:01:15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 13 (class 2615 OID 3022709)
-- Name: anime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA anime;


--
-- TOC entry 959 (class 1247 OID 3022711)
-- Name: season; Type: TYPE; Schema: anime; Owner: -
--

CREATE TYPE anime.season AS ENUM (
    'Spring',
    'Summer',
    'Fall',
    'Winter'
);


--
-- TOC entry 296 (class 1255 OID 3022847)
-- Name: log_in(text); Type: FUNCTION; Schema: anime; Owner: -
--

CREATE FUNCTION anime.log_in(password text) RETURNS TABLE("Logged In?" boolean)
    LANGUAGE plpgsql
    AS $$  
	BEGIN
		IF (SELECT "loggedIn?" FROM credentials) = 't' THEN
			RAISE EXCEPTION 'Already logged in.';
		ELSIF password = 'bernadette' THEN 
			CREATE OR REPLACE TEMPORARY VIEW credentials AS
				SELECT BOOLEAN 't' AS "loggedIn?";
			RAISE NOTICE 'Login successful.'; 
		ELSE 
			CREATE OR REPLACE TEMPORARY VIEW credentials AS
				SELECT BOOLEAN 'f' AS "loggedIn?";
			RAISE NOTICE 'Login unsuccessful.' 
				USING HINT = 'Password incorrect.'; 
		END IF;
		RETURN QUERY
			SELECT "loggedIn?" AS "Logged In?" FROM credentials;
	END
$$;


--
-- TOC entry 297 (class 1255 OID 3022848)
-- Name: log_out(); Type: FUNCTION; Schema: anime; Owner: -
--

CREATE FUNCTION anime.log_out() RETURNS TABLE("Logged In?" boolean)
    LANGUAGE plpgsql
    AS $$  
	BEGIN
		IF (SELECT "loggedIn?" FROM credentials) = 'f' THEN
			RAISE EXCEPTION 'Already logged out.';
		ELSE 
			CREATE OR REPLACE TEMPORARY VIEW credentials AS
				SELECT BOOLEAN 'f' AS "loggedIn?";
			RAISE NOTICE 'Log out successful.'; 
		END IF;
		RETURN QUERY
			SELECT "loggedIn?" AS "Logged In?" FROM credentials;
	END
$$;


--
-- TOC entry 295 (class 1255 OID 3022816)
-- Name: login_check(); Type: FUNCTION; Schema: anime; Owner: -
--

CREATE FUNCTION anime.login_check() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
		IF (SELECT "loggedIn?" FROM credentials) = 'f' THEN
			RAISE EXCEPTION 'Cannot edit the data without logging in.'
				USING HINT = 'Use function log_in() to log in.';
		END IF;
		RETURN NULL;
	END
$$;


--
-- TOC entry 294 (class 1255 OID 3022814)
-- Name: status_error(); Type: FUNCTION; Schema: anime; Owner: -
--

CREATE FUNCTION anime.status_error() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
	BEGIN
	RAISE EXCEPTION 'Cannot update status to that value.'
		USING HINT = 'Anime cannot be un-watched.';
		RETURN NULL;
	END
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 266 (class 1259 OID 3022726)
-- Name: ANIME; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."ANIME" (
    id integer NOT NULL,
    "titleEN" text NOT NULL,
    "titleJP" text NOT NULL,
    season anime.season,
    year integer,
    type text NOT NULL,
    episodes integer,
    CONSTRAINT "ANIME_episodes_check" CHECK ((episodes > 0)),
    CONSTRAINT "ANIME_type_check" CHECK (((type = 'TV'::text) OR (type = 'Movie'::text) OR (type = 'OVA'::text)))
);


--
-- TOC entry 271 (class 1259 OID 3022790)
-- Name: GENRES; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."GENRES" (
    id integer NOT NULL,
    genre text NOT NULL
);


--
-- TOC entry 268 (class 1259 OID 3022747)
-- Name: HISTORY; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."HISTORY" (
    id integer NOT NULL,
    status text NOT NULL,
    year integer,
    rewatched boolean
);


--
-- TOC entry 270 (class 1259 OID 3022771)
-- Name: RATINGS; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."RATINGS" (
    id integer NOT NULL,
    "userScore" real,
    "myScore" integer,
    comment text,
    CONSTRAINT "RATINGS_myScore_check" CHECK ((("myScore" >= 0) AND ("myScore" <= 10))),
    CONSTRAINT "RATINGS_userScore_check" CHECK ((("userScore" >= (0)::double precision) AND ("userScore" <= (10)::double precision)))
);


--
-- TOC entry 269 (class 1259 OID 3022764)
-- Name: SCALE; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."SCALE" (
    score integer NOT NULL,
    meaning text NOT NULL
);


--
-- TOC entry 265 (class 1259 OID 3022719)
-- Name: SEASONS; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."SEASONS" (
    season anime.season NOT NULL,
    "startMonth" text NOT NULL,
    "endMonth" text NOT NULL
);


--
-- TOC entry 267 (class 1259 OID 3022740)
-- Name: STATUSES; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."STATUSES" (
    status text NOT NULL,
    meaning text NOT NULL
);


--
-- TOC entry 272 (class 1259 OID 3022802)
-- Name: STUDIOS; Type: TABLE; Schema: anime; Owner: -
--

CREATE TABLE anime."STUDIOS" (
    id integer NOT NULL,
    studio text NOT NULL
);


--
-- TOC entry 276 (class 1259 OID 3022843)
-- Name: credentials; Type: MATERIALIZED VIEW; Schema: anime; Owner: -
--

CREATE MATERIALIZED VIEW anime.credentials AS
 SELECT false AS "loggedIn?"
  WITH NO DATA;


--
-- TOC entry 275 (class 1259 OID 3022836)
-- Name: my_anime_list; Type: MATERIALIZED VIEW; Schema: anime; Owner: -
--

CREATE MATERIALIZED VIEW anime.my_anime_list AS
 SELECT "ANIME"."titleJP" AS "Title",
    "HISTORY".status AS "Status",
    "RATINGS"."myScore" AS "My Rating",
    "SCALE".meaning AS "Meaning",
    "RATINGS".comment AS "My Comment"
   FROM (((anime."HISTORY"
     JOIN anime."ANIME" ON (("HISTORY".id = "ANIME".id)))
     JOIN anime."RATINGS" ON (("ANIME".id = "RATINGS".id)))
     RIGHT JOIN anime."SCALE" ON (("RATINGS"."myScore" = "SCALE".score)))
  WHERE ("ANIME"."titleJP" IS NOT NULL)
  ORDER BY "ANIME"."titleJP"
  WITH NO DATA;


--
-- TOC entry 274 (class 1259 OID 3022829)
-- Name: to_watch; Type: MATERIALIZED VIEW; Schema: anime; Owner: -
--

CREATE MATERIALIZED VIEW anime.to_watch AS
 SELECT "ANIME"."titleEN" AS "English Title",
    "ANIME"."titleJP" AS "Japanese Title",
    "HISTORY".status AS "Status",
    "HISTORY".year AS "Year Watched",
    "HISTORY".rewatched AS "Rewatched?",
    "SCALE".meaning AS "My Rating"
   FROM (((anime."HISTORY"
     JOIN anime."ANIME" ON (("HISTORY".id = "ANIME".id)))
     JOIN anime."RATINGS" ON (("ANIME".id = "RATINGS".id)))
     RIGHT JOIN anime."SCALE" ON (("RATINGS"."myScore" = "SCALE".score)))
  WHERE ("HISTORY".status = 'Plan to Watch'::text)
  ORDER BY "HISTORY".year DESC, "ANIME"."titleEN"
  WITH NO DATA;


--
-- TOC entry 273 (class 1259 OID 3022822)
-- Name: watch_history; Type: MATERIALIZED VIEW; Schema: anime; Owner: -
--

CREATE MATERIALIZED VIEW anime.watch_history AS
 SELECT "ANIME"."titleEN" AS "English Title",
    "ANIME"."titleJP" AS "Japanese Title",
    "HISTORY".status AS "Status",
    "HISTORY".year AS "Year Watched",
    "HISTORY".rewatched AS "Rewatched?",
    "SCALE".meaning AS "My Rating"
   FROM (((anime."HISTORY"
     JOIN anime."ANIME" ON (("HISTORY".id = "ANIME".id)))
     JOIN anime."RATINGS" ON (("ANIME".id = "RATINGS".id)))
     RIGHT JOIN anime."SCALE" ON (("RATINGS"."myScore" = "SCALE".score)))
  WHERE (NOT ("HISTORY".status = 'Plan to Watch'::text))
  ORDER BY "HISTORY".year DESC, "ANIME"."titleEN"
  WITH NO DATA;


--
-- TOC entry 3541 (class 0 OID 3022726)
-- Dependencies: 266
-- Data for Name: ANIME; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."ANIME" (id, "titleEN", "titleJP", season, year, type, episodes) FROM stdin;
52034	[Oshi no Ko]	[Oshi no Ko]	Spring	2023	TV	11
55791	[Oshi no Ko]  Season 2	[Oshi no Ko] 2nd Season	Summer	2024	TV	13
4654	A Certain Magical Index	Toaru Majutsu no Index	Fall	2008	TV	24
6213	A Certain Scientific Railgun	Toaru Kagaku no Railgun	Fall	2009	TV	24
16049	A Certain Scientific Railgun S	Toaru Kagaku no Railgun S	Spring	2013	TV	24
38481	A Certain Scientific Railgun T	Toaru Kagaku no Railgun T	Winter	2020	TV	25
39195	Beastars	Beastars	Fall	2019	TV	12
40935	Beastars 2nd Season	Beastars 2nd Season	Winter	2021	TV	12
4898	Black Butler	Kuroshitsuji	Fall	2008	TV	24
6707	Black Butler II	Kuroshitsuji II	Summer	2010	TV	12
31812	Black Butler: Book of Circus	Kuroshitsuji Movie: Book of the Atlantic	Summer	2014	Movie	1
22145	Black Butler: Book of Murder 	Kuroshitsuji: Book of Circus	\N	2015	TV	10
23317	Black Butler: Book of the Atlantic 	Kuroshitsuji: Book of Murder	\N	2017	OVA	2
59228	Black Butler: Emerald Witch Arc	Kuroshitsuji: Midori no Majo-hen	\N	\N	TV	13
55855	Black Butler: Public School Arc 	Kuroshitsuji: Kishuku Gakkou-hen	Spring	2024	TV	11
40060	BNA	BNA	Spring	2020	TV	12
31478	Bungou Stray Dogs	Bungou Stray Dogs	Spring	2016	TV	12
32867	Bungou Stray Dogs Season 2	Bungou Stray Dogs 2nd Season	Fall	2016	TV	12
38003	Bungou Stray Dogs Season 3	Bungou Stray Dogs 3rd Season	Spring	2019	TV	12
50330	Bungou Stray Dogs Season 4	Bungou Stray Dogs 4th Season	Winter	2023	TV	13
54898	Bungou Stray Dogs Season 5	Bungou Stray Dogs 5th Season	Summer	2023	TV	11
42250	Bungou Stray Dogs Wan!	Bungou Stray Dogs Wan!	Winter	2021	TV	12
38000	Demon Slayer: Kimetsu no Yaiba	Kimetsu no Yaiba	Spring	2019	TV	26
40456	Demon Slayer: Kimetsu no Yaiba - The Movie: Mugen Train	Kimetsu no Yaiba Movie: Mugen Ressha-hen	\N	2020	Movie	1
20031	D-Frag!	D-Frag!	Winter	2014	TV	12
28171	Food Wars! Shokugeki no Soma	Shokugeki no Souma	Spring	2015	TV	24
54722	Gushing Over Magical Girls	Mahou Shoujo ni Akogarete	Winter	2024	TV	13
53516	I Was Reincarnated as the 7th Prince so I Can Take My Time Perfecting My Magical Ability 	Tensei shitara Dainana Ouji Datta node, Kimama ni Majutsu wo Kiwamemasu	Spring	2024	TV	12
40010	Interspecies Reviewers	Ishuzoku Reviewers	Winter	2020	TV	12
38472	Isekai Quartet	Isekai Quartet	Spring	2019	TV	12
39988	Isekai Quartet 2	Isekai Quartet 2	Winter	2020	TV	12
40748	Jujutsu Kaisen	Jujutsu Kaisen	Fall	2020	TV	24
48561	Jujutsu Kaisen 0	Jujutsu Kaisen 0 Movie	Fall	2021	Movie	1
51009	Jujutsu Kaisen Season 2	Jujutsu Kaisen 2nd Season	Summer	2023	TV	23
51958	KonoSuba: An Explosion on This Wonderful World!	Kono Subarashii Sekai ni Bakuen wo!	Spring	2023	TV	12
38040	KonoSuba: God's Blessing on This Wonderful World! - Legend of Crimson	Kono Subarashii Sekai ni Shukufuku wo! Movie: Kurenai Densetsu	Summer	2019	Movie	1
30831	KonoSuba: God's Blessing on This Wonderful World! 	Kono Subarashii Sekai ni Shukufuku wo!	Winter	2016	TV	10
32937	KonoSuba: God's Blessing on This Wonderful World! 2	Kono Subarashii Sekai ni Shukufuku wo! 2	Winter	2017	TV	10
49458	KonoSuba: God's Blessing on This Wonderful World! 3	Kono Subarashii Sekai ni Shukufuku wo! 3	Spring	2024	TV	11
59833	KonoSuba: God's Blessing on This Wonderful World! 3 OVA	Kono Subarashii Sekai ni Shukufuku wo! 3: Bonus Stage	Spring	2025	OVA	2
33206	Miss Kobayashi's Dragon Maid	Kobayashi-san Chi no Maid Dragon	Winter	2017	TV	13
58426	My Deer Friend Nokotan	Shikanoko Nokonoko Koshitantan	Summer	2024	TV	12
31964	My Hero Academia	Boku no Hero Academia	Spring	2016	TV	13
33486	My Hero Academia Season 2	Boku no Hero Academia 2nd Season	Spring	2017	TV	25
36456	My Hero Academia Season 3	Boku no Hero Academia 3rd Season	Spring	2018	TV	25
38408	My Hero Academia Season 4	Boku no Hero Academia 4th Season	Fall	2019	TV	25
41587	My Hero Academia Season 5	Boku no Hero Academia 5th Season	Spring	2021	TV	25
36896	My Hero Academia: Heroes Rising	Boku no Hero Academia the Movie 1: Futari no Hero	Fall	2019	Movie	1
39565	My Hero Academia: Two Heroes	Boku no Hero Academia the Movie 2: Heroes:Rising	Summer	2018	Movie	1
44200	My Hero Academia: World Heroes' Mission	Boku no Hero Academia the Movie 3: World Heroes' Mission	Summer	2021	Movie	1
38555	My Next Life as a Villainess: All Routes Lead to Doom!	Otome Game no Hametsu Flag shika Nai Akuyaku Reijou ni Tensei shiteshimatta...	Spring	2020	TV	12
30	Neon Genesis Evangelion	Shinseiki Evangelion	Fall	1995	TV	26
52367	No Longer Allowed in Another World	Isekai Shikkaku	Summer	2024	TV	12
29803	Overlord	Overlord	Summer	2015	TV	13
8795	Panty & Stocking with Garterbelt	Panty & Stocking with Garterbelt	Fall	2010	TV	13
31240	Re:ZERO -Starting Life in Another World-	Re:Zero kara Hajimeru Isekai Seikatsu	Spring	2016	TV	25
54855	Senpai is an Otokonoko	Senpai wa Otokonoko	Summer	2024	TV	12
50265	Spy x Family	Spy x Family	Spring	2022	TV	12
37430	That Time I Got Reincarnated as a Slime	Tensei shitara Slime Datta Ken	Fall	2018	TV	24
39551	That Time I Got Reincarnated as a Slime Season 2	Tensei shitara Slime Datta Ken 2nd Season	Winter	2021	TV	12
53580	That Time I Got Reincarnated as a Slime Season 3	Tensei shitara Slime Datta Ken 3rd Season	Spring	2024	TV	24
33255	The Disastrous Life of Saiki K.	Saiki Kusuo no Ψ-nan	Summer	2016	TV	120
34612	The Disastrous Life of Saiki K. 2	Saiki Kusuo no Ψ-nan 2	Winter	2018	TV	24
37779	The Promised Neverland	Yakusoku no Neverland	Winter	2019	TV	12
39617	The Promised Neverland Season 2	Yakusoku no Neverland 2nd Season	Winter	2021	TV	11
37585	Yarichin☆Bitch-bu	Yarichin☆Bitch-bu	Summer	2018	OVA	2
10495	YuruYuri: Happy Go Lily	Yuru Yuri	Summer	2011	TV	12
\.


--
-- TOC entry 3546 (class 0 OID 3022790)
-- Dependencies: 271
-- Data for Name: GENRES; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."GENRES" (id, genre) FROM stdin;
4654	Action
4654	Fantasy
4654	Sci-Fi
6213	Action
6213	Fantasy
6213	Sci-Fi
16049	Action
16049	Fantasy
16049	Sci-Fi
38481	Action
38481	Fantasy
38481	Sci-Fi
39195	Drama
39195	Suspense
40935	Drama
40935	Suspense
4898	Action
4898	Mystery
4898	Supernatural
6707	Action
6707	Comedy
6707	Supernatural
31812	Action
31812	Mystery
31812	Supernatural
22145	Action
22145	Mystery
22145	Supernatural
23317	Action
23317	Mystery
23317	Supernatural
59228	Action
59228	Mystery
59228	Supernatural
55855	Action
55855	Mystery
55855	Supernatural
40060	Action
40060	Fantasy
31478	Action
31478	Mystery
32867	Action
32867	Mystery
38003	Action
38003	Mystery
50330	Action
50330	Mystery
54898	Action
54898	Mystery
42250	Comedy
20031	Comedy
38000	Action  
38000	Award Winning
38000	Supernatural
40456	Action 
40456	Supernatural
28171	Gourmet 
28171	Ecchi
54722	Action   
54722	Comedy
54722	Girls Love
54722	Ecchi
53516	Adventure 
53516	Fantasy
40010	Comedy  
40010	Fantasy
40010	Erotica
38472	Comedy 
38472	Fantasy
39988	Comedy 
39988	Fantasy
40748	Action  
40748	Award Winning
40748	Supernatural
48561	Action 
48561	Supernatural
51009	Action 
51009	Supernatural
51958	Comedy 
51958	Fantasy
38040	Adventure  
38040	Comedy
38040	Fantasy
30831	Adventure  
30831	Comedy
30831	Fantasy
32937	Adventure  
32937	Comedy
32937	Fantasy
49458	Adventure  
49458	Comedy
49458	Fantasy
59833	Adventure  
59833	Comedy
59833	Fantasy
33206	Slice of Life 
33206	Supernatural
58426	Comedy
31964	Action
33486	Action
36456	Action
38408	Action
41587	Action
36896	Action
39565	Action
44200	Action
38555	Comedy  
38555	Fantasy
38555	Romance
30	Action     
30	Avant Garde
30	Award Winning
30	Drama
30	Sci-Fi
30	Suspense
52367	Adventure  
52367	Comedy
52367	Fantasy
29803	Action  
29803	Adventure
29803	Fantasy
8795	Action   
8795	Comedy
8795	Fantasy
8795	Ecchi
31240	Drama  
31240	Fantasy
31240	Suspense
54855	Drama 
54855	Romance
50265	Action  
50265	Award Winning
50265	Comedy
37430	Action  
37430	Comedy
37430	Fantasy
39551	Action  
39551	Comedy
39551	Fantasy
53580	Action  
53580	Comedy
53580	Fantasy
33255	Comedy
34612	Comedy
37779	Mystery
37779	Suspense
39617	Mystery
39617	Suspense
37585	Boys Love  
37585	Comedy
37585	Erotica
10495	Award Winning  
10495	Comedy
10495	Girls Love
52034	Award Winning 
52034	Drama
55791	Drama
\.


--
-- TOC entry 3543 (class 0 OID 3022747)
-- Dependencies: 268
-- Data for Name: HISTORY; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."HISTORY" (id, status, year, rewatched) FROM stdin;
52034	Completed	2024	t
55791	Dropped	2024	f
4654	Dropped	2019	f
6213	Completed	2019	t
16049	Completed	2019	t
38481	Completed	2020	t
39195	Completed	2019	f
40935	Plan to Watch	\N	\N
4898	Completed	\N	t
6707	Completed	\N	f
31812	Completed	2024	t
22145	Completed	2024	f
23317	Completed	2024	t
59228	Plan to Watch	\N	\N
55855	Completed	2024	f
40060	Completed	2023	t
31478	Completed	2025	t
32867	Completed	2025	t
38003	Completed	2025	t
50330	Completed	2025	t
54898	Completed	2025	t
42250	Completed	2025	f
38000	Completed	2023	f
40456	Completed	2023	f
20031	Completed	2019	t
28171	Completed	\N	f
54722	Completed	2025	t
53516	Plan to Watch	\N	\N
40010	Completed	2025	f
38472	Completed	2024	t
39988	Completed	2024	t
40748	Completed	2025	f
48561	Completed	2025	f
51009	Dropped	2025	f
51958	Dropped	2023	t
38040	Completed	2023	f
30831	Completed	2023	t
32937	Completed	2023	t
49458	Completed	2024	t
59833	Plan to Watch	\N	\N
33206	Completed	\N	f
58426	Dropped	2024	f
31964	Completed	2021	t
33486	Completed	2021	t
36456	Completed	2021	t
38408	Completed	2021	t
41587	Dropped	2021	t
36896	Completed	2021	t
39565	Completed	2021	f
44200	Completed	2021	f
38555	Dropped	2024	f
30	Completed	2024	f
52367	Completed	2024	t
29803	Dropped	\N	f
8795	Completed	\N	t
31240	Plan to Watch	\N	\N
54855	Dropped	2025	f
50265	Completed	2022	t
37430	Completed	2020	t
39551	Completed	2020	t
53580	Dropped	2024	f
33255	Completed	2022	t
34612	Plan to Watch	2024	f
37779	Completed	\N	t
39617	Completed	\N	f
37585	Completed	2025	t
10495	Dropped	2021	f
\.


--
-- TOC entry 3545 (class 0 OID 3022771)
-- Dependencies: 270
-- Data for Name: RATINGS; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."RATINGS" (id, "userScore", "myScore", comment) FROM stdin;
52034	8.58	9	Saw so many ads for this in Tokyo and decided to check it out, anyways Kana > Akane
55791	8.58	7	A big fall off from S1, honestly
4654	7.34	5	Skip it and watch Railgun instead
6213	7.65	9	My very first anime (and manga), still holds up today
16049	8	9	The best season, the first half is a cinematic masterpiece
38481	8.15	8	A great revival of my very first anime, lives up to the first seasons
39195	7.8	7	(Rating for S1 only) If you say it's only for furries you're wrong, found it a bit boring tho
40935	7.76	\N	\N
4898	7.65	9	(S1 only) very Tumblr coded but Grell has my heart so *shrug*
6707	7.12	4	This season should never have existed.
31812	8.06	8	Very good, bonus points for Grell inclusion
22145	8.05	7	It was pretty good but the Grell withdrawal is tough
23317	8.24	6	The worst part of Black Butler (minus S2 but I don't even count that)
59228	\N	\N	\N
55855	7.86	7	A good revival but didn't quite capture S1's magic (also I'm sad there was no Grell)
40060	7.34	8	GIVE US SEASON 2 YOU COWARDS
31478	7.81	8	(Rating for S1 only) Honestly a mid show but the characters are amazing, watch this show for the fandom not the show
32867	8.17	6	Tied with S3 for the worst season of BSD
38003	8.2	6	Tied with S2 for the worst season of BSD
50330	8.43	7	Second best season, introduced my favorite characters \nfrom the show
54898	8.62	8	The best season of BSD no contest
42250	7.98	8	It's BSD but not trying to be serious, which is the best kind of BSD
38000	8.44	6	Fights are pretty but the show is SO BORING. Like I can not understate how boring this anime is.
40456	8.56	6	Better than the show, at least it didn't make me fall asleep
20031	7.5	6	Got the manga from my local library and decided to watch the anime, the OP animation perfectly captures the vibe so check that out
28171	8.13	7	Absolute foodgasm but it does get boring after a while
54722	7.63	9	If you can look past anime BS, this show is genuinely amazing
53516	7.43	\N	\N
40010	7.41	8	Honestly this rating is more for the manga, genuinely funny read/watch
38472	7.37	7	I've only seen 2 of the animes included but it was still a really fun watch
39988	7.36	7	I don't know why I listed the seasons separately... if this one was the one with the V-Day episode then I think I liked it better?
40748	8.56	6	I honestly don't get the hype. There's no comedy, the action is boring, and GOJO IS NOT HOT. There. I said it.
48561	8.41	7	Probably the most entertaining JJK thing I watched, entertained me enough to make me want to watch S2
51009	8.76	5	Dropped. I just don't want to watch half a season of flashbacks
51958	7.5	4	Why would I ever want to watch a show all about my least favorite Konosuba character? Also it's just not as funny as Konosuba.
38040	8.41	7	Too much Megumin, not enough Darkness
30831	8.1	10	The best comedy anime in existence. This is a show that I think everyone should watch. You don't have to like isekais to find this show hilarious.
32937	8.25	10	The best season tbh
49458	8.36	10	A Darkness-centric season? Sign me up
59833	\N	\N	\N
33206	7.92	5	Honestly really boring
58426	7.01	6	The concept is funny and the OP is a banger but club shenanigans animes bore me to tears
31964	7.84	6	Great on a first watch but boring in retrospect
33486	8.06	7	The objectively best season, it falls off after here
36456	7.99	7	This is only rated so high for the Bakugo Retrieval Arc (or whatever it's called)
38408	7.86	6	I consider this the last watchable season of MHA. Also idc what you think, the School Festival Arc was great
41587	7.35	5	The last season of MHA I will be watching, I just cannot be bothered to care about the whole war thing. I signed up to watch the school life of superheroes in training, the show has officially departed too far from the school aspect for me. 
36896	7.93	7	This movie made me cry so hard that I swore I'd never watch it again
39565	7.53	8	This rating is pure nostalgia from my days in the MHA fandom
44200	7.58	7	I wish they included literally any side characters from the anime
38555	7.45	6	The first half was pretty good but it fell off QUICK
30	8.36	4	I don't understand why everyone thinks this show is amazing. Maybe it's because I was on an airplane when I watched it, but this show felt like taking acid. It made no sense to me.
52367	7.27	7	Suicidal rizz. That's all I have to say.
29803	7.9	6	I'm sure it's great but I honestly found it SO boring
8795	7.73	7	I wasn't into the ending but it's a good watch to turn your brain off
31240	8.24	\N	\N
54855	7.31	4	Loved the premise, wanted it to be great but I ended up dropping it almost immediately
50265	8.47	8	S1 was great, I remember being neutral towards later seasons
37430	8.14	8	Probably the best execution of the isekai genre
39551	8.36	8	I'm not sure why I put each season separately, I don't even know what's in which season
53580	7.68	4	That time I got reincarnated as a guy in a bunch of meetings. Maybe it gets good at the end, might watch the end someday.
33255	8.41	9	Saiki and I are literally the same person
34612	8.41	\N	\N
37779	8.48	9	The first anime to ever make me cry (RIP Norman)
39617	5.26	3	Made me read the manga, that's the only credit I can give it
37585	6.08	10	Unironic rating. This is a show that everyone should watch at least once. It's really short but it's truly a life changing experience. If you can watch and enjoy this show, then you have the right to claim you are truly impervious to anime BS.
10495	7.56	5	I dislike club shenanigans anime
\.


--
-- TOC entry 3544 (class 0 OID 3022764)
-- Dependencies: 269
-- Data for Name: SCALE; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."SCALE" (score, meaning) FROM stdin;
1	Appalling
2	Horrible
3	Very Bad
4	Bad
5	Average
6	Fine
7	Good
8	Very Good
9	Great
10	Masterpiece
\.


--
-- TOC entry 3540 (class 0 OID 3022719)
-- Dependencies: 265
-- Data for Name: SEASONS; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."SEASONS" (season, "startMonth", "endMonth") FROM stdin;
Spring	January	March
Summer	April	June
Fall	July	September
Winter	October	December
\.


--
-- TOC entry 3542 (class 0 OID 3022740)
-- Dependencies: 267
-- Data for Name: STATUSES; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."STATUSES" (status, meaning) FROM stdin;
Completed	I have watched every episode of the anime.
Dropped	I stopped watching the anime before finishing it and I do not plan to return to it.
Plan to Watch	I have not watched the anime but I plan to someday watch it.
On-Hold	I stopped watching the anime before finishing it but I plan to return to it someday.
\.


--
-- TOC entry 3547 (class 0 OID 3022802)
-- Dependencies: 272
-- Data for Name: STUDIOS; Type: TABLE DATA; Schema: anime; Owner: -
--

COPY anime."STUDIOS" (id, studio) FROM stdin;
52034	Doga Kobo
55791	Doga Kobo
4654	J.C.Staff
6213	J.C.Staff
16049	J.C.Staff
38481	J.C.Staff
39195	Orange
40935	Orange
4898	A-1 Pictures
6707	A-1 Pictures
31812	A-1 Pictures
22145	A-1 Pictures
23317	A-1 Pictures
59228	CloverWorks
55855	CloverWorks
40060	Trigger
31478	Bones
32867	Bones
38003	Bones
50330	Bones
54898	Bones
42250	Bones
42250	Nomad
38000	ufotable
40456	ufotable
20031	Brain's Base
28171	J.C.Staff
54722	Asahi Production
53516	Tsumugi Akita Animation Lab
40010	Passione
38472	Studio PuYUKAI
39988	Studio PuYUKAI
40748	MAPPA
48561	MAPPA
51009	MAPPA
51958	Drive
38040	J.C.Staff
30831	Studio Deen
32937	Studio Deen
49458	Drive
59833	Drive
33206	Kyoto Animation
58426	Wit Studio
31964	Bones
33486	Bones
36456	Bones
38408	Bones
41587	Bones
36896	Bones
39565	Bones
44200	Bones
38555	SILVER LINK.
30	Gainax
30	Tatsunoko Production
52367	Atelier Pontdarc
29803	Madhouse
8795	Gainax
31240	White Fox
54855	Project No.9
50265	Wit Studio
50265	CloverWorks
37430	8bit
39551	8bit
53580	8bit
33255	J.C.Staff
33255	Egg Firm
34612	J.C.Staff
34612	Egg Firm
37779	CloverWorks
39617	CloverWorks
37585	GRIZZLY
10495	Doga Kobo
\.


--
-- TOC entry 3369 (class 2606 OID 3022734)
-- Name: ANIME ANIME_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."ANIME"
    ADD CONSTRAINT "ANIME_pkey" PRIMARY KEY (id);


--
-- TOC entry 3379 (class 2606 OID 3022796)
-- Name: GENRES GENRES_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."GENRES"
    ADD CONSTRAINT "GENRES_pkey" PRIMARY KEY (id, genre);


--
-- TOC entry 3373 (class 2606 OID 3022753)
-- Name: HISTORY HISTORY_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."HISTORY"
    ADD CONSTRAINT "HISTORY_pkey" PRIMARY KEY (id);


--
-- TOC entry 3377 (class 2606 OID 3022779)
-- Name: RATINGS RATINGS_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."RATINGS"
    ADD CONSTRAINT "RATINGS_pkey" PRIMARY KEY (id);


--
-- TOC entry 3375 (class 2606 OID 3022770)
-- Name: SCALE SCALE_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."SCALE"
    ADD CONSTRAINT "SCALE_pkey" PRIMARY KEY (score);


--
-- TOC entry 3367 (class 2606 OID 3022725)
-- Name: SEASONS SEASONS_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."SEASONS"
    ADD CONSTRAINT "SEASONS_pkey" PRIMARY KEY (season);


--
-- TOC entry 3371 (class 2606 OID 3022746)
-- Name: STATUSES STATUSES_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."STATUSES"
    ADD CONSTRAINT "STATUSES_pkey" PRIMARY KEY (status);


--
-- TOC entry 3381 (class 2606 OID 3022808)
-- Name: STUDIOS STUDIOS_pkey; Type: CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."STUDIOS"
    ADD CONSTRAINT "STUDIOS_pkey" PRIMARY KEY (id, studio);


--
-- TOC entry 3389 (class 2620 OID 3022817)
-- Name: ANIME tr_login_check_anime; Type: TRIGGER; Schema: anime; Owner: -
--

CREATE TRIGGER tr_login_check_anime BEFORE INSERT OR DELETE OR UPDATE ON anime."ANIME" FOR EACH STATEMENT EXECUTE FUNCTION anime.login_check();


--
-- TOC entry 3393 (class 2620 OID 3022820)
-- Name: GENRES tr_login_check_genres; Type: TRIGGER; Schema: anime; Owner: -
--

CREATE TRIGGER tr_login_check_genres BEFORE INSERT OR DELETE OR UPDATE ON anime."GENRES" FOR EACH STATEMENT EXECUTE FUNCTION anime.login_check();


--
-- TOC entry 3390 (class 2620 OID 3022818)
-- Name: HISTORY tr_login_check_history; Type: TRIGGER; Schema: anime; Owner: -
--

CREATE TRIGGER tr_login_check_history BEFORE INSERT OR DELETE OR UPDATE ON anime."HISTORY" FOR EACH STATEMENT EXECUTE FUNCTION anime.login_check();


--
-- TOC entry 3392 (class 2620 OID 3022819)
-- Name: RATINGS tr_login_check_ratings; Type: TRIGGER; Schema: anime; Owner: -
--

CREATE TRIGGER tr_login_check_ratings BEFORE INSERT OR DELETE OR UPDATE ON anime."RATINGS" FOR EACH STATEMENT EXECUTE FUNCTION anime.login_check();


--
-- TOC entry 3394 (class 2620 OID 3022821)
-- Name: STUDIOS tr_login_check_studios; Type: TRIGGER; Schema: anime; Owner: -
--

CREATE TRIGGER tr_login_check_studios BEFORE INSERT OR DELETE OR UPDATE ON anime."STUDIOS" FOR EACH STATEMENT EXECUTE FUNCTION anime.login_check();


--
-- TOC entry 3391 (class 2620 OID 3022815)
-- Name: HISTORY tr_status_error; Type: TRIGGER; Schema: anime; Owner: -
--

CREATE TRIGGER tr_status_error BEFORE UPDATE ON anime."HISTORY" FOR EACH ROW WHEN ((new.status = 'Plan to Watch'::text)) EXECUTE FUNCTION anime.status_error();


--
-- TOC entry 3382 (class 2606 OID 3022735)
-- Name: ANIME ANIME_season_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."ANIME"
    ADD CONSTRAINT "ANIME_season_fkey" FOREIGN KEY (season) REFERENCES anime."SEASONS"(season);


--
-- TOC entry 3387 (class 2606 OID 3022797)
-- Name: GENRES GENRES_id_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."GENRES"
    ADD CONSTRAINT "GENRES_id_fkey" FOREIGN KEY (id) REFERENCES anime."ANIME"(id);


--
-- TOC entry 3383 (class 2606 OID 3022759)
-- Name: HISTORY HISTORY_id_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."HISTORY"
    ADD CONSTRAINT "HISTORY_id_fkey" FOREIGN KEY (id) REFERENCES anime."ANIME"(id);


--
-- TOC entry 3384 (class 2606 OID 3022754)
-- Name: HISTORY HISTORY_status_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."HISTORY"
    ADD CONSTRAINT "HISTORY_status_fkey" FOREIGN KEY (status) REFERENCES anime."STATUSES"(status);


--
-- TOC entry 3385 (class 2606 OID 3022780)
-- Name: RATINGS RATINGS_id_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."RATINGS"
    ADD CONSTRAINT "RATINGS_id_fkey" FOREIGN KEY (id) REFERENCES anime."ANIME"(id);


--
-- TOC entry 3386 (class 2606 OID 3022785)
-- Name: RATINGS RATINGS_myScore_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."RATINGS"
    ADD CONSTRAINT "RATINGS_myScore_fkey" FOREIGN KEY ("myScore") REFERENCES anime."SCALE"(score);


--
-- TOC entry 3388 (class 2606 OID 3022809)
-- Name: STUDIOS STUDIOS_id_fkey; Type: FK CONSTRAINT; Schema: anime; Owner: -
--

ALTER TABLE ONLY anime."STUDIOS"
    ADD CONSTRAINT "STUDIOS_id_fkey" FOREIGN KEY (id) REFERENCES anime."ANIME"(id);


--
-- TOC entry 3551 (class 0 OID 3022843)
-- Dependencies: 276 3553
-- Name: credentials; Type: MATERIALIZED VIEW DATA; Schema: anime; Owner: -
--

REFRESH MATERIALIZED VIEW anime.credentials;


--
-- TOC entry 3550 (class 0 OID 3022836)
-- Dependencies: 275 3553
-- Name: my_anime_list; Type: MATERIALIZED VIEW DATA; Schema: anime; Owner: -
--

REFRESH MATERIALIZED VIEW anime.my_anime_list;


--
-- TOC entry 3549 (class 0 OID 3022829)
-- Dependencies: 274 3553
-- Name: to_watch; Type: MATERIALIZED VIEW DATA; Schema: anime; Owner: -
--

REFRESH MATERIALIZED VIEW anime.to_watch;


--
-- TOC entry 3548 (class 0 OID 3022822)
-- Dependencies: 273 3553
-- Name: watch_history; Type: MATERIALIZED VIEW DATA; Schema: anime; Owner: -
--

REFRESH MATERIALIZED VIEW anime.watch_history;


-- Completed on 2025-04-23 12:01:15

--
-- PostgreSQL database dump complete
--

